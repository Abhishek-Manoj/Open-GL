package com.example.lab3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    EditText un2,pwd2;
    Button loginbtn;
    int counter=2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        un2=findViewById(R.id.editTextTextUserName2);
        pwd2=findViewById(R.id.editTextTextPassword2);
        loginbtn=findViewById(R.id.login);
        String runname=getIntent().getStringExtra("unname");
        String rpassword=getIntent().getStringExtra("password");
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uname=un2.getText().toString();
                String password = pwd2.getText().toString();
                if(runname.equals(uname)&& rpassword.equals(password)){
                    Intent in=new Intent(Login.this,LOGINSUCCESSFUL.class);
                    startActivity(in);
                }
                 else{
                    Toast.makeText(Login.this, "Invalid crendentials", Toast.LENGTH_LONG).show();
                }
                 counter--;
                 if(counter==0)
                 {
                     Toast.makeText(Login.this, "Too many failures", Toast.LENGTH_LONG).show();
                     loginbtn.setEnabled(false);
                 }

            }
        });
    }
}