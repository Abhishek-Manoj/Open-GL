#include<stdio.h>
#include<GL/glut.h>
void display(void)
{
 glClear(GL_COLOR_BUFFER_BIT);
glColor3f(0.02,0.741,0.752);
 glBegin(GL_POLYGON); //sky

 glVertex2f(0.0,350.0);
 glVertex2f(0.0,500.0);
 glVertex2f(500.0,500.0);
 glVertex2f(500.0,350.0);
 glEnd();

glBegin(GL_POLYGON); //mountain1
glColor3f(0.33,0.075,0.004);
 glVertex2f(0.0,350.0);
 glVertex2f(166.6,350.0);
 glVertex2f(83.3,500.0);
 glEnd();

glBegin(GL_POLYGON); //mountain2
glColor3f(0.33,0.075,0.004);
 glVertex2f(333.2,350.0);
 glVertex2f(166.6,350.0);
 glVertex2f(249.9,500.0);
 glEnd();

glBegin(GL_POLYGON); //mountain3
glColor3f(0.33,0.075,0.004);
 glVertex2f(333.2,350.0);
 glVertex2f(500.0,350.0);
 glVertex2f(416.2,500.0);
 glEnd();

glColor3f(0.564,1.0,0.0313);
 glBegin(GL_POLYGON); //land

 glVertex2f(0.0,350.0);
 glVertex2f(500.0,350.0);
 glVertex2f(500.0,0.0);
 glVertex2f(0.0,0.0);
 glEnd();

glColor3f(0.859,0.56,0.262);
 glBegin(GL_POLYGON); //house

 glVertex2f(50.0,0.0);
 glVertex2f(200.0,0.0);
 glVertex2f(200.0,150.0);
 glVertex2f(50.0,150.0);
 glEnd();

glBegin(GL_POLYGON); //roof
glColor3f(0.33,0.075,0.004);
 glVertex2f(50.0,150.0);
 glVertex2f(200.0,150.0);
 glVertex2f(125.0,250.0);
 glEnd();

glColor3f(0.33,0.075,0.004);
 glBegin(GL_POLYGON);//door

 glVertex2f(100.0,100.0);
 glVertex2f(100.0,0.0);
 glVertex2f(150.0,0.0);
 glVertex2f(150.0,100.0);
 glEnd(); 

glColor3f(0.33,0.075,0.004);
 glBegin(GL_POLYGON);//tree trunk

 glVertex2f(365.0,200.0);
 glVertex2f(365.0,0.0);
 glVertex2f(385.0,0.0);
 glVertex2f(385.0,200.0);
 glEnd(); 

glBegin(GL_POLYGON); //leaves 1
glColor3f(0.039,0.258,0.015);
 glVertex2f(325.0,150.0);
 glVertex2f(425.0,150.0);
 glVertex2f(375.0,175.0);
 glEnd();

glBegin(GL_POLYGON); //leaves 1
glColor3f(0.039,0.258,0.015);
 glVertex2f(325.0,170.0);
 glVertex2f(425.0,170.0);
 glVertex2f(375.0,195.0);
 glEnd();

glBegin(GL_POLYGON); //leaves 1
glColor3f(0.039,0.258,0.015);
 glVertex2f(325.0,190.0);
 glVertex2f(425.0,190.0);
 glVertex2f(375.0,215.0);
 glEnd();

glBegin(GL_POLYGON); //leaves 1
glColor3f(0.039,0.258,0.015);
 glVertex2f(325.0,210.0);
 glVertex2f(425.0,210.0);
 glVertex2f(375.0,235.0);
 glEnd();

glColor3f(1.0,1.0,1.0); //clouds
glPushMatrix();
glTranslatef(400.0,400.0,0.0);
 glutSolidSphere(30.0,100.0,100.0);
glPopMatrix();
glPushMatrix();
glTranslatef(415.0,415.0,0.0);
 glutSolidSphere(30.0,100.0,100.0);
glPopMatrix();
glPushMatrix();
glTranslatef(425.0,385.0,0.0);
 glutSolidSphere(30.0,100.0,100.0);
glPopMatrix();
glPushMatrix();
glTranslatef(450.0,400.0,0.0);
 glutSolidSphere(30.0,100.0,100.0);
glPopMatrix();

glColor3f(1.0,1.0,1.0); //clouds
glPushMatrix();
glTranslatef(200.0,400.0,0.0);
 glutSolidSphere(30.0,100.0,100.0);
glPopMatrix();
glPushMatrix();
glTranslatef(215.0,415.0,0.0);
 glutSolidSphere(30.0,100.0,100.0);
glPopMatrix();
glPushMatrix();
glTranslatef(225.0,385.0,0.0);
 glutSolidSphere(30.0,100.0,100.0);
glPopMatrix();
glPushMatrix();
glTranslatef(250.0,400.0,0.0);
 glutSolidSphere(30.0,100.0,100.0);
glPopMatrix();

glColor3f(1.0,1.0,0.0);
glPushMatrix();
glTranslatef(333.2,450.0,0.0);
 glutSolidSphere(25.0,100.0,100.0);
glPopMatrix();
 glFlush();
}

int main(int argc,char **argv)
{
 printf("Hello");
 glutInit(&argc,argv);
 glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
 glutInitWindowSize(1000,1000);
 glutInitWindowPosition(0,0);
 glutCreateWindow("First Program");
 glClearColor(0.859,0.56,0.262,0.0);
 glMatrixMode(GL_PROJECTION);
 glLoadIdentity();
 glOrtho(0.0,500.0,0.0,500.0,-450.0,450.0);
 glutDisplayFunc(display);
 glutMainLoop();
}
