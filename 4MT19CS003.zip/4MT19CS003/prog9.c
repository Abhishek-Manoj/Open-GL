#include<stdio.h>
#include<GL/glut.h>
void display(void)
{
 glClear(GL_COLOR_BUFFER_BIT);
 glColor3f(1.0,1.0,1.0);
glPushMatrix();
glTranslatef(400.0,400.0,0.0);
 glutSolidSphere(30.0,100.0,100.0);
glPopMatrix();
glPushMatrix();
glTranslatef(415.0,415.0,0.0);
 glutSolidSphere(30.0,100.0,100.0);
glPopMatrix();
glPushMatrix();
glTranslatef(425.0,385.0,0.0);
 glutSolidSphere(30.0,100.0,100.0);
glPopMatrix();
 glFlush();
}

int main(int argc,char **argv)
{
 printf("Hello");
 glutInit(&argc,argv);
 glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
 glutInitWindowSize(500,500);
 glutInitWindowPosition(100,100);
 glutCreateWindow("First Program");
 glClearColor(0.02,0.741,0.752,0.0);
 glMatrixMode(GL_PROJECTION);
 glLoadIdentity();
 glOrtho(0.0,500.0,0.0,500.0,-450.0,450.0);
 glutDisplayFunc(display);
 glutMainLoop();
}
