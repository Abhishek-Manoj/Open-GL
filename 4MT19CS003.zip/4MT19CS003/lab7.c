#include<stdio.h>
#include<GL/glut.h>
#include<string.h>
GLfloat vertices[4][3]={{0,1,1},{1,0,0},{0,2,0},{-1,0,0}};
int n;
void divide_triangle(float a[],float b[],float c[],int m)
{
 float x[3],y[3],z[3];
 if(m>0)
 {
  for(int j=0;j<3;j++)
  {
   x[j]=(a[j]+b[j])/2;
   y[j]=(a[j]+c[j])/2;
   z[j]=(b[j]+c[j])/2;
  }
  divide_triangle(a,x,y,m-1);
  divide_triangle(y,c,z,m-1);
  divide_triangle(x,z,b,m-1);
 }
 else
 {
  glBegin(GL_POLYGON);
  glVertex3fv(a);
  glVertex3fv(b);
  glVertex3fv(c);
  glEnd();
 }
}

 
void tetrahedron(int m)
{
 glColor3f(1,0,0);
 divide_triangle(vertices[0],vertices[1],vertices[3],m);
 glColor3f(0,1,0);
 divide_triangle(vertices[0],vertices[2],vertices[3],m);
 glColor3f(0,0,1);
 divide_triangle(vertices[0],vertices[2],vertices[1],m);
 glColor3f(0,0,0);
 divide_triangle(vertices[2],vertices[3],vertices[1],m);
}


 
void display()
{
 glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

 tetrahedron(n);
 glFlush();
}


int main(int argc,char** argv)
{
 printf("Enter number of recursions:");
 scanf("%d",&n);
 glutInit(&argc,argv);
 glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB|GLUT_DEPTH);
 glutInitWindowSize(500,500);
 glutInitWindowPosition(0,0);
 glutCreateWindow("Lab6_4MT19CS003");
 glClearColor(1.0,1.0,1.0,1.0);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
 glOrtho(-3.0,3.0,-3.0,3.0,-100.0,100.0);
 glutDisplayFunc(display);
 glEnable(GL_DEPTH_TEST);
 glutMainLoop();
}

